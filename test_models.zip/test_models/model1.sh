#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$HOME/eut+dats-stats-w26"
PROJECT_DIR="$HOME/eut+dats-stats-w26/v2tudembeded-model-with-SIS-final-23-july-updated-sisscriptCPU"
TEST_DIR="$PROJECT_DIR/test_models"

export LD_LIBRARY_PATH="$BASE_DIR/tools/llama.cpp/build/bin:${LD_LIBRARY_PATH:-}"

LLAMA_CLI="$BASE_DIR/tools/llama.cpp/build/bin/llama-completion"
MODEL="$BASE_DIR/models/qwen/Qwen2.5-7B-Instruct-Q4_K_M.gguf"
PROMPTS="$TEST_DIR/prompts.txt"

THREADS=128
TOKENS=220
GPU_LAYERS=0

OUT_TXT="$TEST_DIR/outputs_model1.txt"
TOK_FILE="$TEST_DIR/model1_total_output_tokens.txt"
AVG_TOK_FILE="$TEST_DIR/model1_avg_output_tokens.txt"

: > "$OUT_TXT"
echo 0 > "$TOK_FILE"
echo 0 > "$AVG_TOK_FILE"

total_tokens=0
query_count=0

while IFS= read -r prompt || [[ -n "$prompt" ]]; do
  [[ -z "$prompt" ]] && continue
  query_count=$((query_count + 1))

  output="$(
    "$LLAMA_CLI" \
      -m "$MODEL" \
      -p "$prompt" \
      -n "$TOKENS" \
      --temp 0 \
      -t "$THREADS" \
      -ngl "$GPU_LAYERS" \
      < /dev/null 2>/dev/null
  )"

  token_count="$(
    printf "%s" "$output" | python3 -c '
import re
import sys

text = sys.stdin.read().strip()
parts = re.findall(r"\w+|[^\w\s]", text, flags=re.UNICODE)
print(len(parts))
'
  )"

  total_tokens=$((total_tokens + token_count))

  {
    echo "[$query_count] PROMPT: $prompt"
    echo "[$query_count] OUTPUT TOKENS: $token_count"
    echo "[$query_count] OUTPUT:"
    echo "$output"
    echo
  } >> "$OUT_TXT"

done < "$PROMPTS"

if [[ "$query_count" -gt 0 ]]; then
  avg_tokens="$(
    python3 -c "
total_tokens = $total_tokens
query_count = $query_count
print(round(total_tokens / query_count, 4))
"
  )"
else
  avg_tokens="0"
fi

echo "$total_tokens" > "$TOK_FILE"
echo "$avg_tokens" > "$AVG_TOK_FILE"

echo "Model 1 run complete."
echo "Queries processed: $query_count"
echo "Total output tokens: $total_tokens"
echo "Average output tokens per query: $avg_tokens"
echo "Outputs saved to: $OUT_TXT"
